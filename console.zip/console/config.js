/**
 * (C) 2015 ScalAgent Distributed Technologies
 * All rights reserved
 */

host = 'localhost';	// hostname or IP address
port = 9001;
topic = '/home/Lyon/sido/#';	// topic to subscribe to
useTLS = false;
username = null;
password = null;
// username = "";
// password = "";
cleansession = true;
